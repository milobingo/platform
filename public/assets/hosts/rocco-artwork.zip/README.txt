Original generated PNG artwork is preserved byte-for-byte in originals/.
The 7680x4320 JPEG stage plates in upscaled-8k/ are RGB Lanczos upscales from native originals, with a minimal centered crop to 16:9. They are not native 8K generation.
See manifest.json for true native dimensions and source hashes.
